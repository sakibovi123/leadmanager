import React from "react";
import Sidebar from "../sections/Sidebar";

import MainContent from "../MainContent";

const Campaigns = () => {
    return (
        <>
            <br /><br /><br />
            <div className="flex container mx-auto w-[100%] border">
                <Sidebar />

                
                

            </div>
        </>
    )
}

export default Campaigns