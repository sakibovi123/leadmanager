<?php echo $__env->make("base", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container mx-auto flex">
    <?php echo $__env->make("sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="main-content px-7 py-5">
    <div class="flex items-center justify-between p-3">
        <h1 class="text-2xl font-semibold font-mono">All campaigns</h1>

        <div class="flex items-center justify-around">
            <form>
                <select id="countries" class="font-mono font-semibold bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-1.5 dark:bg-white dark:border-gray-600 dark:placeholder-gray-400 dark:text-dark dark:focus:ring-blue-500 dark:focus:border-blue-500">
                    <option selected>Filter</option>
                    <option value="US">United States</option>
                    <option value="CA">Canada</option>
                    <option value="FR">France</option>
                    <option value="DE">Germany</option>
                  </select>
            </form>
            <div class="text-white">....</div>

   
            <!-- Modal toggle -->
            <button class="block text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800" type="button" data-modal-toggle="authentication-modal">
                + New
             </button>
  
            <!-- Main modal -->
            <div id="authentication-modal" tabindex="-1" aria-hidden="true" class="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-modal md:h-full">
                <div class="relative w-full h-full max-w-md md:h-auto">
                    <!-- Modal content -->
                    <div class="relative bg-white rounded-lg shadow dark:bg-gray-100">
                        <button type="button" class="absolute top-3 right-2.5 text-gray-800 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center dark:hover:bg-gray-800 dark:hover:text-white" data-modal-toggle="authentication-modal">
                            <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"></path></svg>
                            <span class="sr-only">Close modal</span>
                        </button>
                        <div class="px-6 py-6 lg:px-8">
                            <h3 class="mb-4 text-xl font-medium text-gray-900">Sign in to our platform</h3>
                            <form class="space-y-6" action="<?php echo e(route('create-campaign')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field("POST"); ?>
                                
                                <div>
                                    <label for="campaign_title" class="block mb-2 text-sm font-medium text-gray-900">Enter campaign title</label>
                                    <input type="text" name="campaign_title" id="" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:border-gray-500 " placeholder="" required>
                                </div>
                               
                        
                                <button type="submit" class="w-full text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Save</button>
                                
                            </form>
                        </div>
                    </div>
                </div>
            </div> 
  

            </div>
        
    </div>
    <table class="w-[1400px] border-2 p-5 table-auto shadow-xl rounded-xl py-4">
        <thead>
            <tr class="text-center border-b-2 bg-slate-900 text-white">
                <th class="text-md p-3">ID</th>
                <th class="text-md p-3">Strike Date</th>
                <th class="text-md p-3">Campaign</th>
                <th class="text-md p-3" colspan="2">Actions</th>
                
            </tr>
        </thead>
        <tbody>
            <?php if($camps->count() > 0): ?>
            <?php $__currentLoopData = $camps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $camp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="bg-white hover:bg-indigo-100 p-3 cursor-pointer transition delay-50 border">
                <td class="text-center p-3 text-sm font-semibold"><?php echo e($camp->id); ?></td>
                <td class="text-center p-3 text-sm font-semibold"><?php echo e($camp->created_at); ?></td>
                <td class="text-center p-3 text-sm font-semibold"><?php echo e($camp->campaign_title); ?></td>
                <td class="text-center p-3 text-sm font-semibold">

                <div class="flex items-center justify-center">
                    <button id="dropdownDefault" data-dropdown-toggle="dropdown" class="text-white font-medium rounded-lg text-sm px-4 py-2.5 text-center inline-flex items-center" type="button">
                        <i class="fa fa-cog text-xl font-semibold text-black hover:text-blue-600" aria-hidden="true"></i>
                    </button>
                    <form method="POST" action="<?php echo e(url('/delete-campaign/'.$camp->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("DELETE"); ?>
                        <button class="text-white font-medium rounded-lg text-sm px-4 py-2.5 text-center inline-flex items-center" type="submit">
                            <i class="fa fa-trash text-xl font-semibold text-black hover:text-red-600" aria-hidden="true"></i>
                        </button>
                    </form>
                </div>
                <!-- Dropdown menu -->
                <div id="dropdown" class="hidden z-10 w-44 bg-white rounded divide-y divide-gray-100 shadow dark:bg-gray-700">
                    <ul class="py-1 text-sm text-gray-700 dark:text-gray-200" aria-labelledby="dropdownDefault">
                    <li>
                        <a href="#" class="block py-2 px-4 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Leads</a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/campaign-details/'.$camp->id)); ?>" class="block py-2 px-4 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Details</a>
                    </li>
                    <li>
                        <a href="#" class="block py-2 px-4 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Edit</a>
                    </li>
                    <li>
                        <a href="#" class="block py-2 px-4 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Buyers</a>
                    </li>
                    <li>
                        <a href="#" class="block py-2 px-4 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Suppliers</a>
                    </li>
                    </ul>
                </div>

                    
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
      
    </table>
</div>
</div><?php /**PATH E:\LeadManager\LeadManager\resources\views/campaign/campaigns.blade.php ENDPATH**/ ?>