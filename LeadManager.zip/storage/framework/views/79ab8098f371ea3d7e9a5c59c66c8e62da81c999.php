<script src="https://cdn.tailwindcss.com"></script>
<nav className="flex items-center justify-between h-[8vh] bg-slate-800 w-[100%] p-5">
    <div className="">
        <a href="/" className="text-3xl text-blue-600">RAY LEADMANAGER</a>
    </div>
    
    <div className="">1</div>
</nav><?php /**PATH E:\LeadManager\LeadManager\resources\views/header.blade.php ENDPATH**/ ?>