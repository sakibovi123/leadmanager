<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>LEADMANAGER</title>
    <script src="https://cdn.tailwindcss.com"></script>


</head>
<body>
    <nav class="flex items-center justify-between h-[8vh] bg-slate-800 w-[100%] p-5">
        <div class="">
            <a href="/" class="text-3xl text-blue-600">RAY LEADMANAGER</a>
        </div>
        
        <div class="">1</div>
    </nav>

    
</body>
</html>
<?php /**PATH E:\LeadManager\LeadManager\resources\views/base.blade.php ENDPATH**/ ?>